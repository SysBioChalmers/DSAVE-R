# Dissecting Cell-to-Cell Variation in Single-Cell RNA-Seq Data

Installation:

1. Install and load devtools:

install.packages("devtools")

library(devtools)

2. Install from GitHub:

install_github("SysBioChalmers/DSAVE-R")
