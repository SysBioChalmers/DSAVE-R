# Install testthat from CRAN (run only once)
#install.packages("testthat")
library(testthat)

#devtools::load_all()
#test_results <- test_dir("test/test_cases", reporter="progress")
#test_results <- test_dir("C:/Work/MatlabCode/projects/DSAVE-R/DSAVE-R/test/test_cases", reporter="summary")

