#' bc2t_UMIdistribution
#'
#' Part of the DSAVE standard template. Describes number of counts for each cell in the
#' down-sampled dataset after alignment.
#'
#' @format Double-precision vector
#' @source Calculated from the BC dataset.
#'
"bc2t_UMIdistribution"
